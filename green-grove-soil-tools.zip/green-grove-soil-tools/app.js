const el = (id) => document.getElementById(id);

const translations = {
  en: {
    dir: "ltr",
    toggle: "العربية",
    title: "Soil Amendment Calculator",
    subtitle: "Estimate soil volume, amendment volume, and the approximate number of bags required for a planting area.",
    inputsHeading: "Project inputs",
    areaLabel: "Area (m²)",
    depthLabel: "Application depth (cm)",
    mixLabel: "Amendment ratio by volume (%)",
    bagLabel: "Bag size (L)",
    calculateBtn: "Calculate",
    resetBtn: "Reset",
    resultsHeading: "Estimated requirements",
    soilVolumeName: "Root-zone volume",
    amendmentVolumeName: "Amendment volume",
    bagsName: "Approx. bags required",
    noticeTitle: "Important:",
    noticeText: "This is a planning estimate, not an agronomic prescription. Confirm application rates with a qualified agronomist and site-specific soil analysis.",
    aboutHeading: "About this project",
    aboutText: "Green Grove Soil Tools is a small open-source project for growers, landscapers, students, and agricultural teams working with soil amendments in arid and water-conscious environments.",
    invalid: "Please enter valid positive values.",
    formula: (area, depth, mix) => `Formula: ${area} m² × ${depth} cm depth × ${mix}% amendment ratio.`
  },
  ar: {
    dir: "rtl",
    toggle: "English",
    title: "حاسبة محسنات التربة",
    subtitle: "تقدير حجم منطقة الجذور، وحجم محسن التربة، والعدد التقريبي للأكياس اللازمة لمساحة زراعية.",
    inputsHeading: "بيانات المشروع",
    areaLabel: "المساحة (م²)",
    depthLabel: "عمق التطبيق (سم)",
    mixLabel: "نسبة محسن التربة بالحجم (%)",
    bagLabel: "حجم الكيس (لتر)",
    calculateBtn: "احسب",
    resetBtn: "إعادة تعيين",
    resultsHeading: "الاحتياج التقديري",
    soilVolumeName: "حجم منطقة الجذور",
    amendmentVolumeName: "حجم محسن التربة",
    bagsName: "العدد التقريبي للأكياس",
    noticeTitle: "تنبيه:",
    noticeText: "هذه أداة تقدير تخطيطي وليست توصية زراعية. يجب تأكيد معدلات الاستخدام مع مختص زراعي وبناءً على تحليل تربة الموقع.",
    aboutHeading: "عن المشروع",
    aboutText: "Green Grove Soil Tools مشروع مفتوح المصدر موجه للمزارعين ومهندسي تنسيق المواقع والطلاب والفرق الزراعية التي تعمل مع محسنات التربة في البيئات الجافة والمهتمة بكفاءة المياه.",
    invalid: "يرجى إدخال قيم صحيحة وموجبة.",
    formula: (area, depth, mix) => `المعادلة: ${area} م² × عمق ${depth} سم × نسبة محسن ${mix}%.`
  }
};

let language = "en";

function calculate() {
  const area = Number(el("area").value);
  const depthCm = Number(el("depth").value);
  const mixPercent = Number(el("mix").value);
  const bagLiters = Number(el("bagSize").value);

  if (area <= 0 || depthCm <= 0 || mixPercent < 0 || mixPercent > 100 || bagLiters <= 0) {
    alert(translations[language].invalid);
    return;
  }

  // 1 m³ = 1000 L
  const rootZoneM3 = area * (depthCm / 100);
  const amendmentM3 = rootZoneM3 * (mixPercent / 100);
  const amendmentL = amendmentM3 * 1000;
  const bags = Math.ceil(amendmentL / bagLiters);

  el("soilVolume").textContent = `${rootZoneM3.toFixed(2)} m³`;
  el("amendmentVolume").textContent = `${amendmentM3.toFixed(2)} m³ (${Math.round(amendmentL)} L)`;
  el("bags").textContent = bags.toLocaleString(language === "ar" ? "ar-SA" : "en-US");
  el("formula").textContent = translations[language].formula(area, depthCm, mixPercent);
}

function reset() {
  el("area").value = 100;
  el("depth").value = 20;
  el("mix").value = 15;
  el("bagSize").value = 50;
  calculate();
}

function applyLanguage() {
  const t = translations[language];
  document.documentElement.lang = language === "ar" ? "ar" : "en";
  document.documentElement.dir = t.dir;

  const fields = [
    "title", "subtitle", "inputsHeading", "areaLabel", "depthLabel",
    "mixLabel", "bagLabel", "calculateBtn", "resetBtn", "resultsHeading",
    "soilVolumeName", "amendmentVolumeName", "bagsName", "noticeTitle",
    "noticeText", "aboutHeading", "aboutText"
  ];

  fields.forEach((id) => {
    el(id).textContent = t[id];
  });

  el("langToggle").textContent = t.toggle;
  calculate();
}

el("calculateBtn").addEventListener("click", calculate);
el("resetBtn").addEventListener("click", reset);
el("langToggle").addEventListener("click", () => {
  language = language === "en" ? "ar" : "en";
  applyLanguage();
});

applyLanguage();
