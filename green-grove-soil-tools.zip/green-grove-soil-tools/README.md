# Green Grove Soil Tools

A lightweight, open-source set of browser-based agricultural calculators for estimating soil-amendment requirements.

The first tool in this repository is a **Soil Amendment Calculator** that estimates:

- Root-zone volume from area and application depth
- Amendment volume from a user-defined volumetric mix ratio
- Approximate number of bags required from a selected bag size
- Results in cubic metres and litres
- Arabic / English interface

## Why this project exists

Agricultural teams often need quick, transparent planning calculations before preparing a site or requesting material quantities. This project provides simple tools that can be inspected, reused, improved, and adapted without proprietary software.

The project is especially relevant to landscaping, soil improvement, nursery work, arid-region agriculture, and water-conscious planting projects.

## Demo

Open `index.html` directly in a browser, or publish the repository with GitHub Pages.

## Example

For:

- Area: `100 m²`
- Application depth: `20 cm`
- Amendment ratio: `15%`
- Bag size: `50 L`

The calculator determines the total root-zone volume, the corresponding amendment volume, and rounds the bag count upward to the next whole bag.

## Method

The calculations are intentionally simple and transparent:

```text
Root-zone volume (m³) = Area (m²) × Depth (m)

Amendment volume (m³) = Root-zone volume × Amendment ratio

Amendment litres = Amendment volume × 1000

Bag count = ceil(Amendment litres ÷ Bag size in litres)
```

## Important agronomic note

This project provides **planning estimates only**. It does not prescribe a specific amendment ratio, irrigation regime, fertilizer rate, or crop treatment.

Users should determine suitable application rates from:

- Soil analysis
- Crop or planting requirements
- Local agronomic guidance
- Product technical documentation
- Site-specific drainage, salinity, and root-zone conditions

## Run locally

No build step is required.

1. Download or clone this repository.
2. Open `index.html` in any modern browser.
3. Enter your project values.
4. Click **Calculate**.

## GitHub Pages

You can publish it as a free static website:

1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`.
5. Save.

## Project structure

```text
green-grove-soil-tools/
├── index.html
├── style.css
├── app.js
├── README.md
├── CONTRIBUTING.md
├── LICENSE
├── CHANGELOG.md
└── .gitignore
```

## Roadmap

Potential future additions:

- Raised-bed media calculator
- Tree-pit volume calculator
- Bulk material conversion tool
- Irrigation scheduling helper
- CSV export
- Metric / imperial unit conversion
- More Arabic agricultural terminology
- Automated tests

## Contributing

Contributions are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT License. See [LICENSE](LICENSE).

## Maintainer

Green Grove Soil  
Al Madinah, Saudi Arabia
