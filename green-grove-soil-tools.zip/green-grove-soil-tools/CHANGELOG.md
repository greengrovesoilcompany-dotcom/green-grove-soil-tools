# Changelog

All notable changes to this project will be documented here.

## [0.1.0] - 2026-08-18

### Added
- Initial Soil Amendment Calculator
- Root-zone volume calculation
- Amendment volume calculation
- Bag quantity estimate
- Arabic / English interface
- Responsive browser-based UI
- README, contribution guide, MIT license, and project roadmap
