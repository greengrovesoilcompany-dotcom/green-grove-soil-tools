# Contributing

Thank you for your interest in Green Grove Soil Tools.

## Ways to contribute

You can help by:

- Reporting calculation or interface issues
- Improving Arabic or English terminology
- Adding unit tests
- Improving accessibility
- Proposing new agricultural planning calculators
- Improving documentation
- Reviewing formulas and assumptions

## Development

This project currently has no external dependencies.

1. Fork the repository.
2. Create a branch:
   ```bash
   git checkout -b feature/short-description
   ```
3. Make a focused change.
4. Test the calculator in a modern desktop and mobile browser.
5. Commit with a clear message.
6. Open a pull request.

## Pull request guidelines

Please explain:

- What problem the change solves
- What formula or behavior changed
- How you tested it
- Whether documentation needs to be updated

## Agronomic claims

Do not add performance claims, recommended application rates, or crop-specific prescriptions unless they are supported by a clearly cited and appropriate technical source.

The default project should remain a transparent planning calculator rather than a substitute for professional agronomic advice.
